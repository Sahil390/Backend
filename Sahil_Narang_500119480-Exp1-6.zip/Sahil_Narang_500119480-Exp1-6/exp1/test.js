
const io1 = require('./p1.js');
const io2 = require('./p2.js');

console.log('program1 :', io1.greet());
console.log('sap id : ', io2.neobject.sapid);
console.log('Is Student: ', io2.isStudent());

