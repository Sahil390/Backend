const object = {
    neobject : {
        sapid : 500119480.
    },
    isStudent: function() {
        return 'Yes He is student';
    },
}

module.exports = object;