process.stdin.on('data',(data) => {
    console.log("Hello, " + data);
});